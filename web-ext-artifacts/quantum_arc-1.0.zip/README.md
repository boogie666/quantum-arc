# Themes: Quantum Arc Dark

## What it does

Attempt to receate [Arc Dark](https://addons.mozilla.org/en-US/firefox/addon/arc-dark-theme/) with only some success :)....
but until FF add full themeing support this will have to do for me.



